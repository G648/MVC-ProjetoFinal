﻿using MVCRazorCRUD.Context;
using MVCRazorCRUD.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MVCRazorCRUD.Models
{
    public class Professor : UsuarioBase , IProfessor
    {
        public string Cargo { get; set; }

        public void AtualizarProfessor(Professor professor)
        {
            var connection = Conexao.GetConnect();
            connection.Open();
            var query = "update professores set professorNome = @nome, professorEmail = @email, professorEndereco = @end, professorTelefone = @tel, professorCargo = @cargo where professorId = @id";
            var command = new SqlCommand(query, connection);

            command.Parameters.Add("@nome", SqlDbType.VarChar).Value = professor.Nome;
            command.Parameters.Add("@email", SqlDbType.VarChar).Value = professor.Email;
            command.Parameters.Add("@end", SqlDbType.VarChar).Value = professor.Endereco;
            command.Parameters.Add("@tel", SqlDbType.VarChar).Value = professor.Telefone;
            command.Parameters.Add("@cargo", SqlDbType.VarChar).Value = professor.Cargo;
            command.Parameters.Add("@id", SqlDbType.Int).Value = professor.Id;
            command.ExecuteNonQuery();
        }

        public List<Professor> BuscarProfessor(int id)
        {
            var connection = Conexao.GetConnect();
            connection.Open();

            var query = "select * from professores where professorId = @id";
            var command = new SqlCommand(query, connection);
            command.Parameters.Add("@id", SqlDbType.Int).Value = id;

            var dataSet = new DataSet();
            var adapter = new SqlDataAdapter(command);
            adapter.Fill(dataSet);

            var rows = dataSet.Tables[0].Rows;

            List<Professor> listaProfessores = new List< Professor>();
            foreach (DataRow item in rows)
            {
                var Colunas = item.ItemArray;
                Professor professor = new Professor();

                professor.Id = int.Parse(Colunas[0].ToString());
                professor.Nome = Colunas[1].ToString();
                professor.Email = Colunas[2].ToString();
                professor.Endereco = Colunas[3].ToString();
                professor.Telefone = Colunas[4].ToString();
                professor.Cargo = Colunas[5].ToString();
                listaProfessores.Add(professor);
            }

            connection.Close();

            return listaProfessores;
        }

        public Professor CadastrarProfessor(Professor professor)
        {
            try
            {
                var connection = Conexao.GetConnect();
                connection.Open();

                var query = "Insert into professores (professorNome, professorEmail, professorEndereco, professorTelefone, CargoId) values (@nome, @email, @end, @tel, @cargo)";

                var command = new SqlCommand(query, connection);

                command.Parameters.Add("@nome", SqlDbType.VarChar).Value = professor.Nome;
                command.Parameters.Add("@email", SqlDbType.VarChar).Value = professor.Email;
                command.Parameters.Add("@end", SqlDbType.VarChar).Value = professor.Endereco;
                command.Parameters.Add("@tel", SqlDbType.VarChar).Value = professor.Telefone;
               // command.Parameters.Add("@cargo", SqlDbType.VarChar).Value = professor.CargoId;

                command.ExecuteNonQuery();

                connection.Close();
                return professor;

            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Professor> ListarProfessor()
        {
            try
            {

                var connection = Conexao.GetConnect();
                connection.Open();

                var query = "select * from professores";
                var command = new SqlCommand(query, connection);
                var dataSet = new DataSet();
                var adapter = new SqlDataAdapter(command);
                adapter.Fill(dataSet);

                var rows = dataSet.Tables[0].Rows;

                List<Professor> listaDeProfessores = new List<Professor>();

                foreach (DataRow item in rows)
                {
                    Professor professor = new Professor();
                    var Colunas = item.ItemArray;
                    professor.Id = int.Parse(Colunas[0].ToString());
                    professor.Nome = Colunas[1].ToString();
                    professor.Email = Colunas[2].ToString();
                    professor.Endereco = Colunas[3].ToString();
                    professor.Telefone = Colunas[4].ToString();
                    professor.Cargo = Colunas[5].ToString();

                    listaDeProfessores.Add(professor);
                }
                connection.Close();
                return listaDeProfessores;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void RemoverProfessor(int id)
        {
            var connection = Conexao.GetConnect();
            connection.Open();

            var query = "delete from professores where professorId = @id";
            var command = new SqlCommand(query, connection);
            command.Parameters.Add("@id", SqlDbType.Int).Value = id;

            command.ExecuteNonQuery();
        }
    }
}
